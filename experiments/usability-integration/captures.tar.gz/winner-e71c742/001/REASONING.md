## Situation and history
On 2026-10-10 09:00 UTC (event-001) an email from Casey Morgan said the old phone was lost. It asked the bank to change the registered mobile to +9992026000042 today, and said no codes can be received on the old number. At 09:02 an internal note (event-002) recorded that this is an ordinary inbound email. It also recorded that no authenticated session or identity verification result is supplied, that no change has been submitted, and that the customer's preferred contact route is not independently confirmed. The email content is the customer's report. It is not an authenticated record. The full input is in the saved context.md.

## Evidence and gaps
- The requester's identity and authority are not established (event-002).
- The bank's specific lost-phone recovery procedure is not supplied, so the reply can only point to the secure process in general terms. Its steps, channels and timings are unknown.
- The claim that the old phone is lost cannot be verified from the case.

## Why this plan
- **s1 (hold):** The email is unauthenticated, and a sensitive contact change lacks established authority (event-001, event-002). The criterion is that a new phone number cannot authenticate its own change, so an unsafe change is held when authority is not established. The source is the skill's handling rule (skill:cards-access). It is not a supplied bank policy.
- **s2 (route to secure process):** The customer needs a route that works without the old phone. The criterion is to use the bank's supported recovery process and never request codes. The source is again skill:cards-access. The exact procedure would come from bank policy, and none was supplied. s2 follows s1 so the customer is told the change is held, not done.
- The new number is not contacted, because it cannot confirm its own change.

## Execution boundaries
Both steps are pending. s2 depends on s1. The plan stops after the reply, until the customer completes secure identity verification through the bank's process. No other branches are defined.

## Expected result and limits
The change is not made, and the customer is directed to a secure route. The plan does not confirm that the customer will pass verification, how long it will take, or what the procedure details are. The reply must state that the number is unchanged and that verification is required first. It must not promise a change or a completion time, ask for codes, or contact the new number.
