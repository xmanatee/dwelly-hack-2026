## Decision
Hold the requested change of registered mobile number. Disposition: needs_info. Nothing has been executed; both actions below are proposed and pending.

## Proposed actions (in order)
1. **s1 – hold_or_decline (Registered mobile number change):** Hold the request to change the registered mobile to +9992026000042. No change has been submitted, and it should not be submitted from this email.
2. **s2 – route_to_secure_process (Customer), after s1:** Reply to the customer by email with the message below. Do not send anything to the new number.

## Proposed customer message
Dear Casey Morgan,

Thank you for your email. We cannot change a registered mobile number from an email alone, so your mobile number has not been changed. Secure identity verification is required first. Please use the bank's secure identity verification and recovery process for lost-phone contact changes. That process does not depend on codes sent to your old number.

Please do not send us PINs, passwords or one-time codes by email. This reply does not confirm any change, and it does not give a completion time.

Kind regards,
Harrow & Vale Bank plc

## Constraints
- State that the number has not been changed and that secure identity verification comes first.
- Do not claim the number was or will be changed.
- Do not ask for PINs, passwords or one-time codes.
- Do not contact the new number.
- Do not promise a completion time.
