# REASONING.md — Case 002: Payment status discrepancy (TX-0042)

## 1. Situation and history

- **event-001 (2026-10-10 10:00 UTC, verified call, Jules Rowan → H&V service agent):** The customer reports that they authorised a £120 transfer "yesterday", that the recipient says nothing arrived, that they have uploaded the payment screen, and asks whether they should pay again. This is the **customer's report**; the date "yesterday" (2026-10-09 by implication) is the customer's assertion, not a recorded payment date.
- **event-002 (2026-10-10 10:01 UTC, internal note, agent → case record):** The **authenticated record**. Identity and account authority were verified on this call. The bank transfer journal lists TX-0042 for £120 with status "sent". The note explicitly says this does not establish recipient credit. No recall, return or duplicate payment has been initiated. The uploaded screen is customer-supplied evidence, not a receiving-bank confirmation.
- **attachments/payment-screen.txt:** A customer-uploaded text transcription, authenticity not independently verified. Shows Reference TX-0042, Amount GBP 120.00, Screen status "Processing", Capture time not supplied.

The full input is saved in `context.md`.

## 2. Evidence and gaps

**What is established (event-002):**
- Identity and account authority: verified on the call. The customer may therefore receive account-specific information.
- TX-0042, £120, journal status "sent". The reference and amount in the journal match the reference and amount on the customer's screen (attachments/payment-screen.txt), so the transaction being discussed is identified by reference and amount.
- No recall, return or duplicate has been initiated.

**What is not established:**
- **Recipient credit.** Neither event-002 nor the attachment says anything about what the receiving bank did. "Sent" is a payer-side release stage only.
- **Transfer date/time.** The journal note (event-002) does not record when TX-0042 was sent. "Yesterday" (event-001) is unverified.
- **Recipient details.** The journal note does not record the recipient account the payment went to, and the customer has not stated the recipient they intended. A mismatch cannot be ruled in or out.
- **Screen timing.** The attachment shows "Processing" while the journal shows "sent". Because the capture time is not supplied, this could simply be an earlier snapshot; it cannot be resolved from the supplied material and the screen cannot be treated as stronger than the journal.
- **Cause of non-receipt.** Nothing in the record indicates fraud, sanctions screening, balance issues or any other cause. The plan's `must_not` correctly forbids suggesting one.

**Contradictions:** The only apparent conflict is "Processing" (customer screen) vs "sent" (journal). Given the unknown capture time and the unverified nature of the transcription, the journal is treated as authoritative and the screen as corroboration of reference and amount only.

## 3. Why this plan

The plan is preserved as the decision of record; each step's grounds are set out below.

**s1 – reply_to_customer (do not pay again).**
- *Explanation:* The authoritative journal shows TX-0042 as sent with no return or duplicate. If the customer pays again while TX-0042 is still outstanding, both payments may complete, producing a duplicate. Recipient credit is not proven by any supplied record, so the reply states only the "sent" stage and explicitly says it is not receiving-bank confirmation.
- *Evidence:* event-001, event-002, attachments/payment-screen.txt.
- *Criterion:* State only the payment stage the supplied record proves; a payer-side screen is not evidence of recipient credit; do not promise arrival times.
- *Source:* skill:payments (a handling rule of the payments skill, not a quoted bank policy clause or a legal obligation).
- The message also asks the recipient to check with their bank quoting TX-0042 / £120.00 — a low-risk step that uses only the established reference and amount.

**s2 – request_team_action (payment trace).**
- *Explanation:* The journal proves "sent" only; the material gap is whether the receiving bank credited, rejected or returned the funds. That can only be answered by a named trace with the receiving bank. The request also asks operations to record the journal transfer date/time and recipient details, closing two further gaps. It expressly excludes initiating any recall or duplicate, consistent with event-002 (none initiated) and with the aim of not creating a second payment.
- *Evidence:* event-002, event-001.
- *Criterion:* Request a named lookup/trace only for a material gap; distinguish release/sent from recipient credit.
- *Source:* skill:payments.
- The request text carries "customer reports authorisation on 2026-10-09"; this is passed on as the customer's report (derived from "yesterday" on 2026-10-10), not as a recorded date, per `must_not`.

**s3 – ask_customer (intended recipient details).**
- *Explanation:* The note does not record the recipient details. If the customer's intended recipient differs from the recipient recorded against TX-0042, the case is a misdirected payment rather than a delay, and handling would differ. This is a specific fact only the customer can supply. Account name, sort code and account number are ordinary payee details; no PIN, password, card number or one-time code is requested.
- *Evidence:* event-002, request.
- *Criterion:* Identify the exact transaction by reference, amount, date and parties before treating non-receipt as a delay.
- *Source:* skill:payments.

**s4 – reply_to_customer (trace status, conditional on s2).**
- *Explanation:* Telling the customer the trace "has been logged" is a claim about an executed action and must wait for the payments operations team's acknowledgement. Without acknowledgement the customer may only be told the request remains pending and unconfirmed.
- *Evidence:* event-002.
- *Criterion:* A request is not a completed action; report recorded status and what it does not confirm.
- *Source:* general:evidence.

**Alternatives considered within the plan's scope:** Instructing the customer to re-pay is excluded because the journal shows a live "sent" payment with no return — duplicate risk is the dominant hazard. Initiating a recall is not selected because there is no evidence the payment went to a wrong recipient; s3 is the step that would surface such evidence, and any recall would require a fresh decision. Treating the screen's "Processing" as proof the payment is stuck is not supported because the capture time is unknown.

## 4. Execution boundaries

- s1, s2 and s3 have no execution dependencies on each other; s1 and s3 are both addressed to the customer on the verified call and can be delivered together.
- s4 depends on s2: it may only be delivered in its "logged" form after the payments operations team acknowledges the trace request. If no acknowledgement arrives, only the "remains pending and has not been confirmed" form may be used.
- No recall, return, duplicate payment, refund or fraud/sanctions referral is proposed. If s2's trace or s3's answer reveals a misdirected payment, a rejection or a return, that is new information requiring a fresh decision; this plan does not pre-decide those branches.
- `escalate_if` is empty and no safety flags are raised; the plan stops at `needs_info`.

## 5. Expected result and limits

**What the proposed steps could achieve:** The customer is protected from creating a duplicate payment and is given an accurate description of what the bank's own record proves. The trace request, once executed and acknowledged, is the mechanism that can establish credit, rejection or return. The recipient-details question allows the misdirection possibility to be checked against the journal.

**What remains unconfirmed:** Whether the recipient has been credited; when TX-0042 was actually sent; the recipient recorded in the journal; why the customer's screen showed "Processing"; and when (or whether) the funds will arrive. None of these is to be stated or implied until the trace result and journal details are on the case.

**Constraints preserved:** The customer message states the journal status "sent", that "sent" is not recipient credit, that no recall/return/duplicate has been initiated, that they should not pay again now, that a trace is being requested with its result unknown, and that their uploaded screen cannot serve as receiving-bank confirmation. It does not say whether the recipient was credited, does not promise an arrival time, refund or recall outcome, does not claim the trace has been executed, does not treat 2026-10-09 as a recorded date, does not suggest any cause for the delay, and does not instruct the customer to resend.
