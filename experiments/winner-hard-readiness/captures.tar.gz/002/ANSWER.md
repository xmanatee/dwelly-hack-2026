## Decision

**Disposition: escalated.** The plan has two parts:

- Ask the payments operations team to check whether the recipient was credited for transfer **TX-0042** (£120).
- Tell the verified customer, Jules Rowan, the payment status the bank has on record and what that status does not confirm.
- Advise the customer **not to send another £120 for now**. Nothing on record shows the payment failed or was returned, so paying again could mean paying twice.

No action below has been carried out yet. Every step is proposed or pending.

## Proposed actions (in order)

1. **s1 – Ask the payments operations team for a review (pending)**
   - Review TX-0042: GBP 120.00, journal status "sent", authorised by verified customer Jules Rowan.
   - Find out whether the recipient's account was credited.
   - Pass on these details:
     - The customer reports that the recipient says nothing arrived.
     - The customer's uploaded screen shows "Processing". It has no capture time and has not been verified.
     - No recall, return or duplicate payment has been started.
   - This is a **status review only**. It must not start a recall, a return or a new payment.

2. **s2 – Reply to the customer (pending; depends on s1)**
   - Send the reply on the verified call. Wording is below.
   - Only say the review "has been asked for" once s1 is acknowledged. Until then, say the request is still pending.

## Message to the customer (pending wording, for use until s1 is acknowledged)

> Our transfer records show your £120 payment, reference TX-0042, with the status "sent". That confirms it left your account side of the process, but it does not confirm the money has reached the recipient's account, and we can't confirm that yet. Nothing on our records shows the payment failed or was returned, so I'd advise not sending another £120 for now, because you could end up paying twice. A request for our payments team to check whether the recipient was credited is still pending. I can't give you a time for that or promise the result. The screen you uploaded shows "Processing", but it has no capture time, so it may show an earlier stage. It might also help if the recipient checks with their own bank for an incoming £120 payment.

A version that says the review has been asked for is kept separately. It can only be used after s1 is acknowledged.

## Future message draft — NOT SENT

Use only after confirmed execution of: s1.

> Our transfer records show your £120 payment, reference TX-0042, with the status "sent". That confirms it left your account side of the process, but it does not confirm the money has reached the recipient's account, and we can't confirm that yet. Nothing on our records shows the payment failed or was returned, so I'd advise not sending another £120 for now, because you could end up paying twice. We've asked our payments team to check whether the recipient was credited. I can't give you a time for that or promise the result. The screen you uploaded shows "Processing", but it has no capture time, so it may show an earlier stage. It might also help if the recipient checks with their own bank for an incoming £120 payment.
