# REASONING.md

## 1. What happened
- **event-001 (2026-10-10 09:00 UTC, email):** A sender calling themselves Casey Morgan <casey@example.invalid> wrote to Harrow & Vale Bank plc. They said they had lost access to their old phone and could not receive codes on the old number. They asked for the registered mobile to be changed to +9992026000042 "today." This is only what the customer says. Nothing in the case confirms who sent it or that they hold the account.
- **event-002 (2026-10-10 09:02 UTC, internal note):** This is the bank's own record. It says this was an ordinary inbound email, with no authenticated session and no identity verification result. No mobile-number change has been submitted. The customer's preferred contact route is not independently confirmed.

There are no attachments. The full input is in the saved `context.md`.

## 2. Evidence and gaps
- **Confirmed by bank records (event-002):** the channel was unauthenticated email, there is no verification result, and no change has been submitted.
- **Customer's claims only (event-001):** the loss of the old phone, being unable to receive codes, and the sender's identity.
- **Missing (from the plan):**
  - Proof of the sender's identity and right to act on the account. This can only come from the bank's secure identity-recovery process.
  - A contact route for the customer that has been confirmed independently.
- **What we can't tell:**
  - Whether the sender is really the account holder.
  - Whether the old phone or SIM is lost or in someone else's hands.
  - Whether anything else is happening on the account.

  The plan says not to claim the account has been taken over or that fraud has happened. Nothing in the context supports either claim.

## 3. Why this plan
- **s1 – Hold.** The request arrived by plain email with no verification and no change submitted (event-001, event-002). The rule applied: changing contact details is sensitive and needs established identity and authority, and a new phone number can't approve its own change. Changing the number that receives security codes without verification would be unsafe. Source: a handling rule from the `cards-access` skill. It is not a supplied bank policy document or a cited legal obligation.
- **s2 – Refer to a specialist.** The customer says they can't use the old number for code checks, so identity has to be proved some other way. The rule applied: when authority is unresolved, use a verification or support handoff, not an action that changes the account. Source: `cards-access` skill. The referral itself authorises no change. Any decision on the number stays with the secure verification process.
- **s3 – Secure route.** The customer needs a trusted way to prove who they are before any change can be considered. The rule applied: use the bank's supported recovery process through a known, trusted bank contact route. That means the official website, the app or the back of the card, not the email thread. Source: `cards-access` skill.
- **s4 – Reply.** The customer should be told the change hasn't been made, why, and how to make it safely. General safety guidance needs no identification and reveals nothing protected. The rule applied: hold only the unsafe change, give a secure route, still give useful general information, and never ask for a PIN, password or one-time code. Source: `general:safety`.

**Why this order:** The hold (s1) and the secure route (s3) have to be settled first, because the reply (s4) depends on both. The referral (s2) has no dependencies and can happen alongside them.

**Possible tension:** s2 says not to treat the sending email address as a verified route, yet s4 replies to that address. The plan handles this by limiting the reply to general information. The reply confirms no account details and tells the customer to restart contact through official channels. It does not rely on the email being genuine.

## 4. Where the plan stops
- The plan covers four steps: hold, refer, route to the secure process, and reply. All are pending.
- It does not decide whether the number will eventually be changed. That decision belongs to identity-verification / account-recovery colleagues once identity has been proved.
- The plan sets no escalation triggers (`escalate_if` is empty) and no conditional branches.
- If any step can't be carried out, a new decision is needed rather than a different approach made up here.

## 5. Expected result and limits
**What the steps should achieve if carried out:**
- No unverified change is made.
- Recovery colleagues get a clear handoff.
- The customer knows the change hasn't happened and how to proceed safely.

**Still unconfirmed:** the sender's identity, whether any change will be approved, and how long recovery will take.

**The message must say:**
- The registered mobile number has not been changed, and no change has been submitted.
- Number changes can't be made from an email request, and identity must be verified through the bank's secure recovery process.
- The customer should contact the bank using details from the official website, the app or the back of the card.
- The bank will never ask for a PIN, password or one-time passcode.

**The message and actions must not:**
- Say or suggest the number has been or will be changed today.
- Ask for a PIN, password, one-time code or full card details.
- Use or contact +9992026000042 to verify identity or approve the change.
- Disclose account details, balances or the contact details currently on file.
- Say the account has been taken over or that fraud has occurred.
- Promise a completion time or outcome for recovery.
- Treat the sending email address as a verified or confirmed contact route.
